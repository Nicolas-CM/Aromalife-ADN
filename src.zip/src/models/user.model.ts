import mongoose from "mongoose";
import { UserInput } from "../interfaces";

export interface UserDocument extends UserInput, mongoose.Document {
  createdAt: Date;
  updateAt: Date;
  deleteAt: Date;
}

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, index: true, unique: true },
    password: { type: String, required: true },
    age: { type: Number, required: true },
    roles: { type: [String], enum: ["client", "superadmin", "manager"] },
  },
  { timestamps: true, collection: "users" }
);

export const UserModel = mongoose.model<UserDocument>("User", userSchema);
